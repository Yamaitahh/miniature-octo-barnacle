const guides = {
  fortnite: {
    title: "Cómo practicar en Fortnite sin agobiarte",
    intro: "Una rutina breve y repetible suele ser más útil que practicar muchas cosas a la vez.",
    sections: [
      ["1. Calienta durante 5 minutos", "Entra en una zona de práctica y acostúmbrate a los controles. Empieza despacio y prioriza la precisión."],
      ["2. Separa las habilidades", "Dedica unos minutos a construir, otros a editar y otros a apuntar. Cuando te salga cada parte por separado, enlaza dos acciones."],
      ["3. Practica con un objetivo", "Por ejemplo: hacer una edición limpia cinco veces seguidas. Si te atascas, baja la velocidad y vuelve a intentarlo."],
      ["4. Descansa y revisa", "Haz pausas y fíjate en qué acción te cuesta más. No hace falta entrenar durante horas para aprender."]
    ]
  },
  pc: {
    title: "Los componentes básicos de un PC",
    intro: "Un ordenador funciona gracias a varias piezas que trabajan juntas. Estas son las más importantes.",
    sections: [
      ["Procesador (CPU)", "Ejecuta instrucciones y coordina muchas tareas del ordenador."],
      ["Memoria RAM", "Guarda temporalmente los datos que se están usando. No es lo mismo que el almacenamiento."],
      ["Tarjeta gráfica (GPU)", "Procesa imágenes y gráficos. Es especialmente importante en juegos y aplicaciones 3D."],
      ["Almacenamiento (SSD o HDD)", "Guarda el sistema, las aplicaciones y tus archivos aunque apagues el ordenador."],
      ["Placa base y fuente", "La placa conecta los componentes y la fuente proporciona energía con los voltajes adecuados."]
    ]
  },
  fps: {
    title: "Qué son los FPS y por qué importan",
    intro: "FPS significa fotogramas por segundo: cuántas imágenes puede mostrar o producir el juego cada segundo.",
    sections: [
      ["Más FPS puede dar más fluidez", "Pasar de 30 a 60 FPS suele hacer que el movimiento se vea más fluido, si la pantalla y el juego pueden mostrarlo."],
      ["No lo son todo", "La estabilidad importa: unos 60 FPS estables pueden sentirse mejor que una cifra alta que cambia constantemente."],
      ["La pantalla también cuenta", "Los hercios (Hz) indican cuántas veces por segundo puede actualizarse una pantalla. FPS y Hz están relacionados, pero no son lo mismo."],
      ["Cómo mejorar el rendimiento", "Cierra aplicaciones innecesarias, revisa los ajustes gráficos y comprueba que el equipo cumple los requisitos del juego."]
    ]
  }
};

const guideGrid = document.querySelector("#guideGrid");
const searchInput = document.querySelector("#guideSearch");
const filterButtons = [...document.querySelectorAll(".filter-chip")];
const emptyState = document.querySelector("#emptyState");
let activeFilter = "Todas";

function filterGuides() {
  const query = searchInput.value.trim().toLocaleLowerCase("es");
  let visible = 0;
  document.querySelectorAll(".guide-card").forEach(card => {
    const matchesFilter = activeFilter === "Todas" || card.dataset.category === activeFilter;
    const searchable = `${card.dataset.search} ${card.innerText}`.toLocaleLowerCase("es");
    const matchesQuery = searchable.includes(query);
    const show = matchesFilter && matchesQuery;
    card.classList.toggle("hidden", !show);
    if (show) visible++;
  });
  emptyState.classList.toggle("hidden", visible > 0);
}

searchInput.addEventListener("input", filterGuides);
filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    activeFilter = button.dataset.filter;
    filterButtons.forEach(b => b.classList.toggle("active", b === button));
    filterGuides();
  });
});

const dialog = document.querySelector("#guideDialog");
const dialogContent = document.querySelector("#dialogContent");
document.querySelectorAll(".read-guide").forEach(button => {
  button.addEventListener("click", () => {
    const guide = guides[button.dataset.guide];
    if (!guide) return;
    dialogContent.replaceChildren();
    const heading = document.createElement("h2");
    heading.textContent = guide.title;
    const intro = document.createElement("p");
    intro.textContent = guide.intro;
    dialogContent.append(heading, intro);
    guide.sections.forEach(([title, body]) => {
      const h3 = document.createElement("h3");
      h3.textContent = title;
      const p = document.createElement("p");
      p.textContent = body;
      dialogContent.append(h3, p);
    });
    dialog.showModal();
  });
});
document.querySelector("#closeDialog").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", event => {
  if (event.target === dialog) dialog.close();
});

const menuToggle = document.querySelector("#menuToggle");
const mainNav = document.querySelector("#mainNav");
menuToggle.addEventListener("click", () => {
  const open = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.setAttribute("aria-label", open ? "Cerrar menú" : "Abrir menú");
});
mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

const games = [];
const gameList = document.querySelector("#gameList");
const driveSize = document.querySelector("#driveSize");
const usedSpace = document.querySelector("#usedSpace");
const freeSpace = document.querySelector("#freeSpace");
const progressBar = document.querySelector("#progressBar");
const storageMessage = document.querySelector("#storageMessage");

function renderGames() {
  gameList.replaceChildren();
  if (games.length === 0) {
    const empty = document.createElement("li");
    empty.className = "list-placeholder";
    empty.textContent = "Todavía no has añadido juegos.";
    gameList.append(empty);
  } else {
    games.forEach((game, index) => {
      const item = document.createElement("li");
      const name = document.createElement("span");
      name.textContent = `${game.name} — ${game.size} GB`;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.textContent = "×";
      remove.setAttribute("aria-label", `Quitar ${game.name}`);
      remove.addEventListener("click", () => {
        games.splice(index, 1);
        renderGames();
      });
      item.append(name, remove);
      gameList.append(item);
    });
  }
  updateStorage();
}

function updateStorage() {
  const total = Number(driveSize.value);
  const used = games.reduce((sum, game) => sum + game.size, 0);
  const remaining = total - used;
  usedSpace.textContent = `${used} GB`;
  freeSpace.textContent = `${remaining} GB`;
  const percent = Math.min(100, (used / total) * 100);
  progressBar.style.width = `${percent}%`;
  if (used === 0) storageMessage.textContent = "Añade juegos para ver el cálculo.";
  else if (remaining < 0) storageMessage.textContent = `Te faltan ${Math.abs(remaining)} GB: los juegos superan la capacidad elegida.`;
  else storageMessage.textContent = `Los juegos ocuparían aproximadamente el ${percent.toFixed(1).replace(".", ",")}% de la capacidad seleccionada.`;
  freeSpace.style.color = remaining < 0 ? "#ff9eaa" : "";
}
document.querySelector("#addGame").addEventListener("click", () => {
  const [name, size] = document.querySelector("#gameSelect").value.split("|");
  games.push({name, size: Number(size)});
  renderGames();
});
document.querySelector("#clearGames").addEventListener("click", () => {
  games.length = 0;
  renderGames();
});
driveSize.addEventListener("change", updateStorage);
renderGames();
